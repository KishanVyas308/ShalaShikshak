import React from 'react';

/**
 * DEPRECATED: This component is no longer used.
 * We now use simple analytics without complex tabs and charts.
 * See /pages/admin/Analytics.tsx for the new simple analytics dashboard.
 */
const OverviewTab: React.FC = () => {
  return null;
};

export default OverviewTab;
