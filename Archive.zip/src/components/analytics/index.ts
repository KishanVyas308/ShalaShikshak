/**
 * DEPRECATED: These components are no longer used.
 * We now use simple analytics without complex components.
 * See /pages/admin/Analytics.tsx for the new simple analytics dashboard.
 */

// Re-export deprecated stubs for backward compatibility
export { default as AnalyticsHeader } from './AnalyticsHeader';
export { default as Charts } from './Charts';
export { default as ContentAnalyticsTab } from './ContentAnalyticsTab';
export { default as ErrorState } from './ErrorState';
export { default as LoadingState } from './LoadingState';
export { default as OverviewTab } from './OverviewTab';
export { default as PlatformAnalyticsTab } from './PlatformAnalyticsTab';
export { default as QuickInsights } from './QuickInsights';
export { default as StatsCards } from './StatsCards';
export { default as TabNavigation } from './TabNavigation';
export { default as TimeAnalyticsTab } from './TimeAnalyticsTab';
export { default as TopPages } from './TopPages';
